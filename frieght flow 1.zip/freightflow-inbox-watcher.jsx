import { useState, useEffect, useCallback } from "react";

// ─── Email Templates ───────────────────────────────────────────────────────────
const buildEmail = (load, type) => {
  if (type === "invoice") return {
    to: [load.shipperEmail],
    subject: `Invoice #INV-${load.id} — ${load.shipper} | ${load.origin} → ${load.destination}`,
    body: `Dear ${load.shipper} Accounts Payable Team,\n\nPlease find below the invoice for the following shipment:\n\nLoad ID:        ${load.id}\nOrigin:         ${load.origin}\nDestination:    ${load.destination}\nEquipment:      ${load.equipment}\nMiles:          ${(load.miles||0).toLocaleString()}\nShip Date:      ${load.date}\n\n──────────────────────────────\nAMOUNT DUE:     $${Number(load.shipperRate).toLocaleString()}\n──────────────────────────────\n\nPayment due within 30 days. Remit via ACH or check.\n\nACH Details:\n  Bank: First National Bank\n  Routing: 021000021\n  Account: 4521987630\n\nThank you for your business.\nFreightFlow Brokerage | billing@freightflow.com | (555) 800-1234`,
  };
  if (type === "reminder") return {
    to: [load.shipperEmail],
    subject: `PAYMENT REMINDER: Invoice #INV-${load.id} — $${Number(load.shipperRate).toLocaleString()} Due`,
    body: `Dear ${load.shipper} Team,\n\nInvoice #INV-${load.id} for $${Number(load.shipperRate).toLocaleString()} is currently outstanding.\n\nLoad: ${load.id} | ${load.origin} → ${load.destination}\nDate: ${load.date} | Status: ${(load.invoiceStatus||"").toUpperCase()}\n\nPlease process payment at your earliest convenience.\n\nFreightFlow Brokerage`,
  };
  return {
    to: [load.carrierEmail],
    subject: `Payment Remittance — Load ${load.id} | $${Number(load.carrierRate).toLocaleString()}`,
    body: `Dear ${load.carrier},\n\nPayment confirmation for Load ${load.id}:\n\nRoute: ${load.origin} → ${load.destination}\nEquipment: ${load.equipment}\n\n──────────────────────────────\nGROSS RATE:     $${Number(load.shipperRate).toLocaleString()}\nBROKER MARGIN:  $${(Number(load.shipperRate)-Number(load.carrierRate)).toLocaleString()}\nCARRIER PAY:    $${Number(load.carrierRate).toLocaleString()}\n──────────────────────────────\n\nACH payment within 2–3 business days.\n\nFreightFlow Brokerage | (555) 800-1234`,
  };
};

// ─── API Calls ─────────────────────────────────────────────────────────────────
async function callClaude(messages, systemPrompt, useMCP = false) {
  const body = {
    model: "claude-sonnet-4-20250514",
    max_tokens: 1000,
    system: systemPrompt,
    messages,
  };
  if (useMCP) {
    body.mcp_servers = [{ type: "url", url: "https://gmailmcp.googleapis.com/mcp/v1", name: "gmail-mcp" }];
  }
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data;
}

async function scanGmailForRateConfs() {
  const data = await callClaude([{
    role: "user",
    content: `Search Gmail for rate confirmation emails from load boards or shippers. 
    Use query: subject:(rate confirmation OR "rate con" OR "load confirmation" OR "booking confirmation") newer_than:7d
    Get up to 10 threads. For each thread, return the thread ID, subject, sender, and snippet.
    Return ONLY a JSON array like: [{"threadId":"...","subject":"...","from":"...","snippet":"..."}]
    If none found, return [].`
  }], "You are a Gmail assistant. Search for rate confirmation emails and return structured JSON only. No markdown, no explanation.", true);

  const text = data.content.filter(b => b.type === "text").map(b => b.text).join("");
  const clean = text.replace(/```json|```/g, "").trim();
  try { return JSON.parse(clean); } catch { return []; }
}

async function getThreadDetails(threadId) {
  const data = await callClaude([{
    role: "user",
    content: `Get the full content of Gmail thread ID: ${threadId}. Return ALL text from the email body.`
  }], "You are a Gmail assistant. Fetch the thread and return the complete email body text only.", true);
  return data.content.filter(b => b.type === "text").map(b => b.text).join("");
}

async function parseRateConfirmation(emailBody, subject, from) {
  const data = await callClaude([{
    role: "user",
    content: `Parse this rate confirmation email and extract load details.\n\nSUBJECT: ${subject}\nFROM: ${from}\nBODY:\n${emailBody}\n\nReturn ONLY valid JSON with these exact fields (use empty string if not found):\n{"shipper":"","origin":"","destination":"","equipment":"Dry Van","miles":"","shipperRate":"","carrierRate":"","carrier":"","carrierEmail":"","shipperEmail":"","date":""}\n\nFor rates: extract numbers only (no $ signs). For date: use YYYY-MM-DD format. For miles: number only.`
  }], "You are a freight data parser. Extract load details from rate confirmation emails. Return only valid JSON, no markdown, no explanation.");

  const text = data.content.filter(b => b.type === "text").map(b => b.text).join("");
  const clean = text.replace(/```json|```/g, "").trim();
  try { return JSON.parse(clean); } catch { return null; }
}

async function createGmailDraft(load, type) {
  const email = buildEmail(load, type);
  const data = await callClaude([{
    role: "user",
    content: `Create a Gmail draft with exactly these details:\nTO: ${email.to[0]}\nSUBJECT: ${email.subject}\nBODY:\n${email.body}\n\nUse the create_draft tool now.`
  }], "You are a Gmail assistant. Create drafts exactly as instructed.", true);
  return data;
}

// ─── Sample Data ───────────────────────────────────────────────────────────────
const SAMPLE_LOADS = [
  { id: "LD-1001", shipper: "Apex Manufacturing", origin: "Chicago, IL", destination: "Dallas, TX", equipment: "Dry Van", miles: 921, shipperRate: 2850, carrierRate: 2400, carrier: "Blue Ridge Trucking", carrierEmail: "dispatch@blueridge.com", shipperEmail: "ap@apexmfg.com", status: "delivered", invoiceStatus: "unpaid", paymentStatus: "unpaid", date: "2024-06-01", source: "manual" },
  { id: "LD-1002", shipper: "Summit Foods", origin: "Atlanta, GA", destination: "Miami, FL", equipment: "Reefer", miles: 663, shipperRate: 3100, carrierRate: 2600, carrier: "Coastal Carriers LLC", carrierEmail: "pay@coastalcarriers.com", shipperEmail: "billing@summitfoods.com", status: "delivered", invoiceStatus: "paid", paymentStatus: "paid", date: "2024-06-03", source: "manual" },
  { id: "LD-1003", shipper: "TechParts Inc", origin: "Detroit, MI", destination: "Nashville, TN", equipment: "Flatbed", miles: 512, shipperRate: 1950, carrierRate: 1600, carrier: "Heartland Freight", carrierEmail: "accounting@heartlandfreight.com", shipperEmail: "logistics@techparts.com", status: "in_transit", invoiceStatus: "pending", paymentStatus: "pending", date: "2024-06-05", source: "manual" },
  { id: "LD-1004", shipper: "Greenfield Retail", origin: "Los Angeles, CA", destination: "Phoenix, AZ", equipment: "Dry Van", miles: 372, shipperRate: 1400, carrierRate: 1100, carrier: "Desert Express", carrierEmail: "dispatch@desertexpress.com", shipperEmail: "ap@greenfieldretail.com", status: "delivered", invoiceStatus: "overdue", paymentStatus: "unpaid", date: "2024-05-28", source: "manual" },
];

const invColors = { paid:{bg:"#d1fae5",text:"#065f46"}, unpaid:{bg:"#fef3c7",text:"#92400e"}, overdue:{bg:"#fee2e2",text:"#991b1b"}, pending:{bg:"#1e2130",text:"#888"} };
const statColors = { delivered:{bg:"#d1fae5",text:"#065f46"}, in_transit:{bg:"#dbeafe",text:"#1e40af"}, pending:{bg:"#1e2130",text:"#888"} };

// ─── Main App ──────────────────────────────────────────────────────────────────
export default function FreightFlow() {
  const [loads, setLoads] = useState(SAMPLE_LOADS);
  const [tab, setTab] = useState("dashboard");
  const [emailPreview, setEmailPreview] = useState(null);
  const [sending, setSending] = useState({});
  const [notif, setNotif] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [scanResults, setScanResults] = useState([]); // emails found but not yet imported
  const [importing, setImporting] = useState({});
  const [newLoad, setNewLoad] = useState({ shipper:"",origin:"",destination:"",equipment:"Dry Van",miles:"",shipperRate:"",carrierRate:"",carrier:"",carrierEmail:"",shipperEmail:"",date:"" });

  const toast = (msg, type="success") => {
    setNotif({msg,type});
    setTimeout(()=>setNotif(null), 4500);
  };

  // ── Gmail Watcher ────────────────────────────────────────────────────────────
  const runScan = useCallback(async () => {
    setScanning(true);
    setScanResults([]);
    try {
      const threads = await scanGmailForRateConfs();
      if (!threads.length) { toast("No rate confirmation emails found in the last 7 days.", "info"); setScanning(false); return; }
      toast(`Found ${threads.length} potential rate confirmation email${threads.length>1?"s":""}. Parsing...`);
      setScanResults(threads.map(t => ({ ...t, status: "found", parsed: null })));

      // Parse each one
      const results = [];
      for (const thread of threads) {
        try {
          const body = await getThreadDetails(thread.threadId);
          const parsed = await parseRateConfirmation(body, thread.subject, thread.from);
          results.push({ ...thread, status: parsed ? "parsed" : "failed", parsed });
        } catch {
          results.push({ ...thread, status: "failed", parsed: null });
        }
      }
      setScanResults(results);
      const good = results.filter(r => r.status === "parsed").length;
      toast(`Parsed ${good} of ${threads.length} emails. Review below to import.`);
    } catch (err) {
      toast(`Scan failed: ${err.message}`, "error");
    }
    setScanning(false);
  }, []);

  const importLoad = (result) => {
    if (!result.parsed) return;
    setImporting(i => ({...i, [result.threadId]: true}));
    const id = `LD-${1000 + loads.length + Math.floor(Math.random()*100)}`;
    const load = {
      id,
      shipper: result.parsed.shipper || "Unknown Shipper",
      origin: result.parsed.origin || "",
      destination: result.parsed.destination || "",
      equipment: result.parsed.equipment || "Dry Van",
      miles: Number(result.parsed.miles) || 0,
      shipperRate: Number(result.parsed.shipperRate) || 0,
      carrierRate: Number(result.parsed.carrierRate) || 0,
      carrier: result.parsed.carrier || "",
      carrierEmail: result.parsed.carrierEmail || "",
      shipperEmail: result.parsed.shipperEmail || "",
      date: result.parsed.date || new Date().toISOString().split("T")[0],
      status: "pending",
      invoiceStatus: "pending",
      paymentStatus: "pending",
      source: "gmail",
    };
    setLoads(l => [...l, load]);
    setScanResults(r => r.map(x => x.threadId === result.threadId ? { ...x, status: "imported" } : x));
    setImporting(i => ({...i, [result.threadId]: false}));
    toast(`✓ Load ${id} imported from Gmail.`);
  };

  // ── Email Actions ────────────────────────────────────────────────────────────
  const openPreview = (load, type) => {
    const email = buildEmail(load, type);
    setEmailPreview({ ...email, type, load });
  };

  const sendDraft = async (load, type) => {
    const key = `${load.id}-${type}`;
    setSending(s => ({...s, [key]: true}));
    try {
      await createGmailDraft(load, type);
      toast(`✓ Gmail draft created for ${load.id} — check Drafts to send.`);
      setEmailPreview(null);
    } catch (err) {
      toast(`Draft failed: ${err.message}`, "error");
    }
    setSending(s => ({...s, [key]: false}));
  };

  const markInvoicePaid = (id) => { setLoads(l => l.map(x => x.id===id ? {...x,invoiceStatus:"paid"} : x)); toast("Invoice marked paid."); };
  const markCarrierPaid = (id) => { setLoads(l => l.map(x => x.id===id ? {...x,paymentStatus:"paid"} : x)); toast("Carrier payment marked sent."); };

  const addLoad = () => {
    if (!newLoad.shipper||!newLoad.shipperRate) return;
    const id = `LD-${1000+loads.length+1}`;
    setLoads(l => [...l, {...newLoad, id, miles:Number(newLoad.miles), shipperRate:Number(newLoad.shipperRate), carrierRate:Number(newLoad.carrierRate), status:"pending", invoiceStatus:"pending", paymentStatus:"pending", source:"manual"}]);
    setNewLoad({shipper:"",origin:"",destination:"",equipment:"Dry Van",miles:"",shipperRate:"",carrierRate:"",carrier:"",carrierEmail:"",shipperEmail:"",date:""});
    toast(`Load ${id} added.`);
    setTab("loads");
  };

  // ── Stats ────────────────────────────────────────────────────────────────────
  const revenue = loads.reduce((s,l)=>s+Number(l.shipperRate),0);
  const costs = loads.reduce((s,l)=>s+Number(l.carrierRate),0);
  const margin = revenue - costs;
  const overdue = loads.filter(l=>l.invoiceStatus==="overdue").reduce((s,l)=>s+Number(l.shipperRate),0);
  const gmailLoads = loads.filter(l=>l.source==="gmail").length;

  // ── Styles ───────────────────────────────────────────────────────────────────
  const S = {
    app: {minHeight:"100vh",background:"#0c0e14",color:"#ddd",fontFamily:"'DM Mono','Courier New',monospace"},
    hdr: {borderBottom:"1px solid #1a1d28",padding:"0 28px",display:"flex",alignItems:"center",justifyContent:"space-between",height:58,background:"#08090f"},
    logo: {fontSize:16,fontWeight:700,letterSpacing:2,color:"#eee",fontFamily:"Georgia,serif"},
    acc: {color:"#f97316"},
    badge: (c,b)=>({fontSize:10,background:b||"#14532d",color:c||"#4ade80",border:`1px solid ${c||"#16a34a"}`,borderRadius:3,padding:"2px 8px",marginLeft:8,letterSpacing:1}),
    nav: {display:"flex",gap:3},
    nb: (a)=>({background:a?"#f97316":"transparent",color:a?"#000":"#555",border:"none",padding:"5px 13px",borderRadius:4,cursor:"pointer",fontSize:11,letterSpacing:1,fontFamily:"inherit",fontWeight:a?700:400}),
    body: {padding:"24px 28px",maxWidth:1240,margin:"0 auto"},
    g4: {display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:24},
    card: {background:"#11131c",border:"1px solid #1a1d28",borderRadius:7,padding:"18px 22px"},
    oCard: {background:"#180d05",border:"1px solid #6b2d0a"},
    gCard: {background:"#051810",border:"1px solid #0d4a2a"},
    lbl: {fontSize:10,color:"#444",letterSpacing:2,marginBottom:6,textTransform:"uppercase"},
    val: {fontSize:24,fontWeight:700,color:"#eee",fontFamily:"Georgia,serif"},
    sub: {fontSize:11,color:"#444",marginTop:3},
    sec: {fontSize:10,letterSpacing:3,color:"#444",textTransform:"uppercase",marginBottom:14},
    tbl: {width:"100%",borderCollapse:"collapse"},
    th: {textAlign:"left",fontSize:9,letterSpacing:2,color:"#3a3d4a",padding:"7px 10px",borderBottom:"1px solid #1a1d28",textTransform:"uppercase"},
    td: {padding:"10px 10px",borderBottom:"1px solid #12141e",fontSize:12,verticalAlign:"middle"},
    bge: (c)=>({background:c.bg,color:c.text,padding:"2px 9px",borderRadius:20,fontSize:10,fontWeight:600,display:"inline-block"}),
    abtn: (c)=>({background:"transparent",color:c||"#666",border:`1px solid ${c||"#252830"}`,borderRadius:4,padding:"3px 9px",fontSize:10,cursor:"pointer",fontFamily:"inherit",marginRight:3}),
    modal: {position:"fixed",inset:0,background:"rgba(0,0,0,0.9)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:100,padding:20},
    mbox: {background:"#11131c",border:"1px solid #252830",borderRadius:10,padding:26,maxWidth:620,width:"100%",maxHeight:"85vh",overflow:"auto"},
    ebdy: {background:"#08090f",border:"1px solid #1a1d28",borderRadius:5,padding:18,fontSize:12,lineHeight:1.9,whiteSpace:"pre-wrap",color:"#aaa",marginTop:10},
    inp: {background:"#08090f",border:"1px solid #252830",borderRadius:4,color:"#ddd",padding:"7px 11px",fontSize:12,fontFamily:"inherit",width:"100%",boxSizing:"border-box"},
    flbl: {fontSize:10,color:"#444",letterSpacing:1,marginBottom:3,display:"block",textTransform:"uppercase"},
    fg: {display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:14},
    sel: {background:"#08090f",border:"1px solid #252830",borderRadius:4,color:"#ddd",padding:"7px 11px",fontSize:12,fontFamily:"inherit",width:"100%"},
    notif: (t)=>({position:"fixed",bottom:20,right:20,background:t==="error"?"#3b0a0a":t==="info"?"#0a1a3b":"#051810",border:`1px solid ${t==="error"?"#dc2626":t==="info"?"#2563eb":"#16a34a"}`,color:t==="error"?"#f87171":t==="info"?"#93c5fd":"#4ade80",borderRadius:6,padding:"11px 18px",fontSize:12,zIndex:200,maxWidth:420}),
    scanCard: {background:"#0d1117",border:"1px solid #1a1d28",borderRadius:6,padding:"14px 16px",marginBottom:10},
    scanStatus: (s)=>({fontSize:10,letterSpacing:1,padding:"2px 8px",borderRadius:3,fontWeight:600,background:s==="imported"?"#052e16":s==="parsed"?"#0d2a1a":s==="failed"?"#2a0808":"#1a1d28",color:s==="imported"?"#4ade80":s==="parsed"?"#86efac":s==="failed"?"#f87171":"#666"}),
  };

  const typeLabel = {invoice:"📄 Invoice",reminder:"🔔 Reminder",carrierPayment:"💸 Carrier Remittance"};

  return (
    <div style={S.app}>
      {/* Header */}
      <div style={S.hdr}>
        <div style={S.logo}>
          FREIGHT<span style={S.acc}>FLOW</span>
          <span style={S.badge()}>● GMAIL LIVE</span>
          {gmailLoads > 0 && <span style={S.badge("#60a5fa","#0c1a3b")}>{gmailLoads} AUTO-IMPORTED</span>}
        </div>
        <div style={S.nav}>
          {[["dashboard","DASHBOARD"],["inbox","📥 INBOX WATCHER"],["loads","LOADS"],["invoices","INVOICES"],["payments","PAYMENTS"],["add_load","+ LOAD"]].map(([t,lbl])=>(
            <button key={t} style={S.nb(tab===t)} onClick={()=>setTab(t)}>{lbl}</button>
          ))}
        </div>
      </div>

      <div style={S.body}>

        {/* ── DASHBOARD ── */}
        {tab==="dashboard" && (<>
          <div style={{marginBottom:18}}><div style={S.sec}>Overview</div></div>
          <div style={S.g4}>
            <div style={S.card}><div style={S.lbl}>Revenue</div><div style={S.val}>${revenue.toLocaleString()}</div><div style={S.sub}>{loads.length} loads total</div></div>
            <div style={S.card}><div style={S.lbl}>Carrier Costs</div><div style={S.val}>${costs.toLocaleString()}</div><div style={S.sub}>Gross outflow</div></div>
            <div style={{...S.card,...S.oCard}}><div style={S.lbl}>Broker Margin</div><div style={{...S.val,color:"#f97316"}}>${margin.toLocaleString()}</div><div style={S.sub}>{revenue>0?((margin/revenue)*100).toFixed(1):0}% avg</div></div>
            <div style={S.card}><div style={S.lbl}>Overdue</div><div style={{...S.val,color:overdue>0?"#f87171":"#eee"}}>${overdue.toLocaleString()}</div><div style={S.sub}>{loads.filter(l=>l.invoiceStatus==="unpaid"||l.invoiceStatus==="overdue").length} unpaid</div></div>
          </div>

          {/* Gmail watcher summary */}
          <div style={{...S.card,...S.gCard,marginBottom:16,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
            <div>
              <div style={S.lbl}>Gmail Inbox Watcher</div>
              <div style={{fontSize:13,color:"#86efac"}}>Auto-imports rate confirmations from your inbox</div>
              <div style={{fontSize:11,color:"#555",marginTop:4}}>{gmailLoads} loads imported from Gmail so far</div>
            </div>
            <button onClick={()=>setTab("inbox")} style={{background:"#052e16",color:"#4ade80",border:"1px solid #16a34a",borderRadius:5,padding:"8px 18px",fontSize:11,cursor:"pointer",fontFamily:"inherit",letterSpacing:1}}>
              SCAN INBOX →
            </button>
          </div>

          <div style={S.card}>
            <div style={S.sec}>Recent Loads</div>
            <table style={S.tbl}>
              <thead><tr>{["Load","Shipper","Route","Rate","Margin","Invoice","Source"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>{loads.slice(-8).reverse().map(l=>(
                <tr key={l.id}>
                  <td style={{...S.td,color:"#f97316",fontWeight:600}}>{l.id}</td>
                  <td style={S.td}>{l.shipper}</td>
                  <td style={{...S.td,color:"#555",fontSize:11}}>{l.origin} → {l.destination}</td>
                  <td style={S.td}>${Number(l.shipperRate).toLocaleString()}</td>
                  <td style={{...S.td,color:"#4ade80",fontWeight:600}}>+${(Number(l.shipperRate)-Number(l.carrierRate)).toLocaleString()}</td>
                  <td style={S.td}><span style={S.bge(invColors[l.invoiceStatus]||invColors.pending)}>{l.invoiceStatus}</span></td>
                  <td style={S.td}><span style={{fontSize:10,color:l.source==="gmail"?"#60a5fa":"#444"}}>{l.source==="gmail"?"📥 Gmail":"✏️ Manual"}</span></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </>)}

        {/* ── INBOX WATCHER ── */}
        {tab==="inbox" && (
          <div>
            <div style={S.sec}>Gmail Inbox Watcher</div>
            <div style={{...S.card,marginBottom:20}}>
              <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:16}}>
                <div>
                  <div style={{fontSize:14,color:"#eee",marginBottom:6}}>Auto-Import Rate Confirmations</div>
                  <div style={{fontSize:12,color:"#555",lineHeight:1.7}}>
                    Scans your Gmail inbox for rate confirmation emails from the last 7 days.<br/>
                    Claude reads each one and extracts: shipper, carrier, origin, destination, rates, and more.<br/>
                    Review the parsed data, then click Import to add it as a load.
                  </div>
                </div>
                <button
                  onClick={runScan}
                  disabled={scanning}
                  style={{background:scanning?"#1a1d28":"#f97316",color:scanning?"#666":"#000",border:"none",borderRadius:5,padding:"10px 22px",fontWeight:700,fontSize:12,cursor:scanning?"default":"pointer",fontFamily:"inherit",letterSpacing:1,whiteSpace:"nowrap"}}
                >
                  {scanning ? "⟳ SCANNING..." : "📥 SCAN INBOX NOW"}
                </button>
              </div>
            </div>

            {scanResults.length === 0 && !scanning && (
              <div style={{...S.card,textAlign:"center",padding:40,color:"#333"}}>
                <div style={{fontSize:32,marginBottom:12}}>📭</div>
                <div style={{fontSize:13}}>No scan results yet. Click "Scan Inbox Now" to check for rate confirmations.</div>
              </div>
            )}

            {scanResults.map(result => (
              <div key={result.threadId} style={S.scanCard}>
                <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:16}}>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
                      <span style={S.scanStatus(result.status)}>{result.status.toUpperCase()}</span>
                      <span style={{fontSize:12,color:"#888",fontWeight:600}}>{result.subject}</span>
                    </div>
                    <div style={{fontSize:11,color:"#444",marginBottom:8}}>From: {result.from}</div>

                    {result.parsed && result.status !== "imported" && (
                      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,background:"#08090f",borderRadius:5,padding:"10px 12px",border:"1px solid #1a1d28"}}>
                        {[
                          ["Shipper", result.parsed.shipper],
                          ["Carrier", result.parsed.carrier],
                          ["Origin", result.parsed.origin],
                          ["Destination", result.parsed.destination],
                          ["Shipper Rate", result.parsed.shipperRate ? `$${Number(result.parsed.shipperRate).toLocaleString()}` : "—"],
                          ["Carrier Rate", result.parsed.carrierRate ? `$${Number(result.parsed.carrierRate).toLocaleString()}` : "—"],
                          ["Equipment", result.parsed.equipment],
                          ["Date", result.parsed.date],
                        ].map(([k,v])=>(
                          <div key={k}>
                            <div style={{fontSize:9,color:"#3a3d4a",letterSpacing:1,textTransform:"uppercase",marginBottom:2}}>{k}</div>
                            <div style={{fontSize:12,color:v?"#ccc":"#2a2d38"}}>{v||"Not found"}</div>
                          </div>
                        ))}
                      </div>
                    )}

                    {result.status === "imported" && (
                      <div style={{fontSize:12,color:"#4ade80"}}>✓ Successfully imported as a load</div>
                    )}
                    {result.status === "failed" && (
                      <div style={{fontSize:12,color:"#f87171"}}>Could not parse this email. Try adding the load manually.</div>
                    )}
                  </div>

                  {result.status === "parsed" && (
                    <button
                      onClick={() => importLoad(result)}
                      disabled={importing[result.threadId]}
                      style={{background:"#052e16",color:"#4ade80",border:"1px solid #16a34a",borderRadius:5,padding:"8px 16px",fontSize:11,cursor:"pointer",fontFamily:"inherit",letterSpacing:1,whiteSpace:"nowrap"}}
                    >
                      {importing[result.threadId] ? "IMPORTING..." : "⬇ IMPORT LOAD"}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── LOADS ── */}
        {tab==="loads" && (
          <div style={S.card}>
            <div style={S.sec}>All Loads ({loads.length})</div>
            <table style={S.tbl}>
              <thead><tr>{["Load","Shipper","Carrier","Route","Rate","Pay","Margin","Invoice","Src","Actions"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>{loads.map(l=>(
                <tr key={l.id}>
                  <td style={{...S.td,color:"#f97316",fontWeight:600}}>{l.id}</td>
                  <td style={S.td}>{l.shipper}</td>
                  <td style={{...S.td,color:"#888"}}>{l.carrier||"—"}</td>
                  <td style={{...S.td,color:"#555",fontSize:11}}>{l.origin} → {l.destination}</td>
                  <td style={S.td}>${Number(l.shipperRate).toLocaleString()}</td>
                  <td style={S.td}>${Number(l.carrierRate).toLocaleString()}</td>
                  <td style={{...S.td,color:"#4ade80",fontWeight:600}}>+${(Number(l.shipperRate)-Number(l.carrierRate)).toLocaleString()}</td>
                  <td style={S.td}><span style={S.bge(invColors[l.invoiceStatus]||invColors.pending)}>{l.invoiceStatus}</span></td>
                  <td style={S.td}><span style={{fontSize:10,color:l.source==="gmail"?"#60a5fa":"#444"}}>{l.source==="gmail"?"📥":"✏️"}</span></td>
                  <td style={S.td}>
                    <button style={S.abtn("#60a5fa")} onClick={()=>openPreview(l,"invoice")}>📄</button>
                    <button style={S.abtn("#a78bfa")} onClick={()=>openPreview(l,"carrierPayment")}>💸</button>
                  </td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}

        {/* ── INVOICES ── */}
        {tab==="invoices" && (
          <div style={S.card}>
            <div style={S.sec}>Shipper Invoices</div>
            <table style={S.tbl}>
              <thead><tr>{["Invoice","Shipper","Route","Amount","Date","Status","Actions"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>{loads.map(l=>(
                <tr key={l.id}>
                  <td style={{...S.td,color:"#f97316"}}>INV-{l.id}</td>
                  <td style={S.td}>{l.shipper}</td>
                  <td style={{...S.td,color:"#555",fontSize:11}}>{l.origin} → {l.destination}</td>
                  <td style={{...S.td,fontWeight:600}}>${Number(l.shipperRate).toLocaleString()}</td>
                  <td style={{...S.td,color:"#444"}}>{l.date}</td>
                  <td style={S.td}><span style={S.bge(invColors[l.invoiceStatus]||invColors.pending)}>{l.invoiceStatus}</span></td>
                  <td style={S.td}>
                    <button style={S.abtn("#60a5fa")} onClick={()=>openPreview(l,"invoice")}>📧 Send</button>
                    {(l.invoiceStatus==="unpaid"||l.invoiceStatus==="overdue")&&<button style={S.abtn("#fbbf24")} onClick={()=>openPreview(l,"reminder")}>🔔</button>}
                    {l.invoiceStatus!=="paid"&&<button style={S.abtn("#4ade80")} onClick={()=>markInvoicePaid(l.id)}>✓</button>}
                  </td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}

        {/* ── PAYMENTS ── */}
        {tab==="payments" && (
          <div style={S.card}>
            <div style={S.sec}>Carrier Payments</div>
            <table style={S.tbl}>
              <thead><tr>{["Load","Carrier","Gross","Margin","Carrier Pay","Status","Actions"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>{loads.map(l=>(
                <tr key={l.id}>
                  <td style={{...S.td,color:"#f97316"}}>{l.id}</td>
                  <td style={S.td}>{l.carrier||"—"}</td>
                  <td style={S.td}>${Number(l.shipperRate).toLocaleString()}</td>
                  <td style={{...S.td,color:"#f97316"}}>−${(Number(l.shipperRate)-Number(l.carrierRate)).toLocaleString()}</td>
                  <td style={{...S.td,fontWeight:700,color:"#4ade80"}}>${Number(l.carrierRate).toLocaleString()}</td>
                  <td style={S.td}><span style={S.bge(invColors[l.paymentStatus]||invColors.pending)}>{l.paymentStatus}</span></td>
                  <td style={S.td}>
                    <button style={S.abtn("#a78bfa")} onClick={()=>openPreview(l,"carrierPayment")}>📧</button>
                    {l.paymentStatus!=="paid"&&<button style={S.abtn("#4ade80")} onClick={()=>markCarrierPaid(l.id)}>✓ Sent</button>}
                  </td>
                </tr>
              ))}</tbody>
            </table>
            <div style={{marginTop:16,padding:"12px 16px",background:"#08090f",borderRadius:5,border:"1px solid #1a1d28",display:"flex",justifyContent:"space-between"}}>
              <span style={{color:"#444",fontSize:12}}>Total Due to Carriers</span>
              <span style={{color:"#eee",fontWeight:700}}>${loads.filter(l=>l.paymentStatus!=="paid").reduce((s,l)=>s+Number(l.carrierRate),0).toLocaleString()}</span>
            </div>
          </div>
        )}

        {/* ── ADD LOAD ── */}
        {tab==="add_load" && (
          <div style={{...S.card,maxWidth:680}}>
            <div style={S.sec}>Add New Load Manually</div>
            <div style={S.fg}>
              {[["Shipper","shipper","text"],["Carrier","carrier","text"],["Origin","origin","text"],["Destination","destination","text"],["Miles","miles","number"],["Ship Date","date","date"],["Shipper Rate ($)","shipperRate","number"],["Carrier Rate ($)","carrierRate","number"],["Shipper Email","shipperEmail","email"],["Carrier Email","carrierEmail","email"]].map(([lbl,key,type])=>(
                <div key={key}><label style={S.flbl}>{lbl}</label><input style={S.inp} type={type} value={newLoad[key]} onChange={e=>setNewLoad({...newLoad,[key]:e.target.value})}/></div>
              ))}
            </div>
            <div style={{marginBottom:18}}>
              <label style={S.flbl}>Equipment</label>
              <select style={S.sel} value={newLoad.equipment} onChange={e=>setNewLoad({...newLoad,equipment:e.target.value})}>
                {["Dry Van","Reefer","Flatbed","Step Deck","Lowboy","Tanker","Box Truck"].map(e=><option key={e}>{e}</option>)}
              </select>
            </div>
            {newLoad.shipperRate&&newLoad.carrierRate&&(
              <div style={{marginBottom:18,padding:"10px 14px",background:"#051810",borderRadius:5,border:"1px solid #0d4a2a"}}>
                <span style={{color:"#444",fontSize:11}}>Margin: </span>
                <span style={{color:"#4ade80",fontWeight:700}}>${(Number(newLoad.shipperRate)-Number(newLoad.carrierRate)).toLocaleString()}</span>
                <span style={{color:"#2a2d38",fontSize:11}}> ({newLoad.shipperRate>0?(((newLoad.shipperRate-newLoad.carrierRate)/newLoad.shipperRate)*100).toFixed(1):0}%)</span>
              </div>
            )}
            <button onClick={addLoad} style={{background:"#f97316",color:"#000",border:"none",borderRadius:5,padding:"9px 26px",fontWeight:700,fontSize:12,cursor:"pointer",fontFamily:"inherit",letterSpacing:1}}>ADD LOAD →</button>
          </div>
        )}
      </div>

      {/* ── EMAIL MODAL ── */}
      {emailPreview && (
        <div style={S.modal} onClick={()=>setEmailPreview(null)}>
          <div style={S.mbox} onClick={e=>e.stopPropagation()}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
              <div>
                <div style={{fontSize:10,color:"#f97316",letterSpacing:2,marginBottom:3,textTransform:"uppercase"}}>{typeLabel[emailPreview.type]}</div>
                <div style={{fontSize:10,color:"#4ade80",letterSpacing:1}}>● Creates draft in your Gmail — review then send</div>
              </div>
              <button onClick={()=>setEmailPreview(null)} style={{background:"transparent",border:"1px solid #252830",color:"#555",borderRadius:4,padding:"3px 9px",cursor:"pointer",fontSize:11,fontFamily:"inherit"}}>✕</button>
            </div>
            <div style={{marginBottom:5}}><span style={{fontSize:10,color:"#333",letterSpacing:1}}>TO: </span><span style={{fontSize:12,color:"#60a5fa"}}>{emailPreview.to[0]}</span></div>
            <div style={{marginBottom:10}}><span style={{fontSize:10,color:"#333",letterSpacing:1}}>SUBJECT: </span><span style={{fontSize:12,color:"#ddd"}}>{emailPreview.subject}</span></div>
            <div style={S.ebdy}>{emailPreview.body}</div>
            <div style={{marginTop:16,display:"flex",gap:10}}>
              <button
                onClick={()=>sendDraft(emailPreview.load,emailPreview.type)}
                disabled={sending[`${emailPreview.load.id}-${emailPreview.type}`]}
                style={{background:sending[`${emailPreview.load.id}-${emailPreview.type}`]?"#1a1d28":"#15803d",color:sending[`${emailPreview.load.id}-${emailPreview.type}`]?"#4ade80":"#fff",border:"1px solid #16a34a",borderRadius:5,padding:"8px 18px",fontWeight:700,fontSize:11,cursor:"pointer",fontFamily:"inherit",letterSpacing:1}}
              >
                {sending[`${emailPreview.load.id}-${emailPreview.type}`]?"CREATING...":"📨 CREATE GMAIL DRAFT"}
              </button>
              <button onClick={()=>{navigator.clipboard?.writeText(emailPreview.body);toast("Copied.");}} style={{background:"transparent",color:"#444",border:"1px solid #1a1d28",borderRadius:4,padding:"8px 14px",fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>📋 Copy</button>
            </div>
            <div style={{marginTop:8,fontSize:10,color:"#333"}}>Opens in your Gmail Drafts folder for final review before sending.</div>
          </div>
        </div>
      )}

      {/* ── NOTIFICATION ── */}
      {notif && <div style={S.notif(notif.type)}>{notif.msg}</div>}
    </div>
  );
}
