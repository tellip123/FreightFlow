import { useState } from "react";

// ─── Mock Auth & Data Store ───────────────────────────────────────────────────
// In production, replace with Supabase: https://supabase.com
// supabase.auth.signInWithPassword(), signInWithOAuth(), signUp(), etc.

const ADMIN_EMAIL = "admin@freightflow.com";

const MOCK_USERS = [
  { id: "u1", email: "admin@freightflow.com", name: "Admin", role: "admin", company: "FreightFlow HQ", avatar: "AF", active: true, joined: "2024-01-01" },
  { id: "u2", email: "jason@midwestbrokers.com", name: "Jason Cole", role: "broker", company: "Midwest Brokers LLC", avatar: "JC", active: true, joined: "2024-03-15" },
  { id: "u3", email: "sara@sunbeltfreight.com", name: "Sara Nguyen", role: "broker", company: "Sunbelt Freight Co.", avatar: "SN", active: true, joined: "2024-04-02" },
  { id: "u4", email: "mike@atlaslogistics.com", name: "Mike Torres", role: "broker", company: "Atlas Logistics", avatar: "MT", active: false, joined: "2024-05-10" },
];

const MOCK_LOADS = {
  u2: [
    { id:"LD-2001", shipper:"AutoParts Inc", origin:"Detroit, MI", destination:"Memphis, TN", shipperRate:2200, carrierRate:1800, invoiceStatus:"paid", date:"2024-06-01" },
    { id:"LD-2002", shipper:"Grain Co", origin:"Kansas City, MO", destination:"St. Louis, MO", shipperRate:950, carrierRate:750, invoiceStatus:"unpaid", date:"2024-06-04" },
    { id:"LD-2003", shipper:"Steel Works", origin:"Cleveland, OH", destination:"Pittsburgh, PA", shipperRate:1400, carrierRate:1100, invoiceStatus:"overdue", date:"2024-05-29" },
  ],
  u3: [
    { id:"LD-3001", shipper:"Sun Fresh Produce", origin:"Phoenix, AZ", destination:"Las Vegas, NV", shipperRate:1800, carrierRate:1400, invoiceStatus:"paid", date:"2024-06-02" },
    { id:"LD-3002", shipper:"Desert Building Supply", origin:"Tucson, AZ", destination:"Albuquerque, NM", shipperRate:2100, carrierRate:1700, invoiceStatus:"unpaid", date:"2024-06-05" },
  ],
  u4: [
    { id:"LD-4001", shipper:"Atlas Retail", origin:"Boston, MA", destination:"New York, NY", shipperRate:1100, carrierRate:850, invoiceStatus:"paid", date:"2024-05-20" },
  ],
};

const MOCK_PASSWORDS = {
  "admin@freightflow.com": "admin123",
  "jason@midwestbrokers.com": "broker123",
  "sara@sunbeltfreight.com": "broker123",
  "mike@atlaslogistics.com": "broker123",
};

// ─── Colors ───────────────────────────────────────────────────────────────────
const C = {
  bg: "#09090f", surf: "#0f1018", card: "#13151f", border: "#1c1f2e",
  text: "#e2e2e2", sub: "#4a4d5e", muted: "#2a2d3e",
  accent: "#f97316", green: "#4ade80", blue: "#60a5fa",
  red: "#f87171", yellow: "#fbbf24", purple: "#a78bfa",
};

const invColors = {
  paid:    { bg:"#052e16", text:"#4ade80", dot:"#16a34a" },
  unpaid:  { bg:"#422006", text:"#fb923c", dot:"#ea580c" },
  overdue: { bg:"#450a0a", text:"#f87171", dot:"#dc2626" },
  pending: { bg:"#1a1d28", text:"#555",    dot:"#374151" },
};

// ─── Reusable Components ──────────────────────────────────────────────────────
const Badge = ({ label, colors }) => (
  <span style={{ background:colors.bg, color:colors.text, padding:"2px 10px", borderRadius:20, fontSize:10, fontWeight:700 }}>{label}</span>
);

const Input = ({ label, type="text", value, onChange, placeholder }) => (
  <div style={{ marginBottom:16 }}>
    <label style={{ display:"block", fontSize:10, color:C.sub, letterSpacing:2, textTransform:"uppercase", marginBottom:6 }}>{label}</label>
    <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
      style={{ width:"100%", background:C.surf, border:`1px solid ${C.border}`, borderRadius:6, padding:"10px 14px", color:C.text, fontSize:13, fontFamily:"inherit", boxSizing:"border-box" }} />
  </div>
);

const Btn = ({ label, onClick, variant="primary", disabled, small }) => {
  const styles = {
    primary: { background:C.accent, color:"#000", border:"none" },
    secondary: { background:"transparent", color:C.sub, border:`1px solid ${C.muted}` },
    danger: { background:"#450a0a", color:C.red, border:`1px solid #7f1d1d` },
    success: { background:"#052e16", color:C.green, border:`1px solid #166534` },
    google: { background:C.surf, color:C.text, border:`1px solid ${C.border}` },
  };
  return (
    <button onClick={onClick} disabled={disabled}
      style={{ ...styles[variant], borderRadius:6, padding:small?"6px 14px":"11px 22px", fontWeight:700, fontSize:small?11:13, cursor:disabled?"default":"pointer", fontFamily:"inherit", letterSpacing:1, opacity:disabled?0.5:1, display:"flex", alignItems:"center", gap:8, justifyContent:"center" }}>
      {label}
    </button>
  );
};

// ─── Login Screen ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true); setError("");
    await new Promise(r => setTimeout(r, 600));
    const user = MOCK_USERS.find(u => u.email === email);
    if (!user) { setError("No account found with that email."); setLoading(false); return; }
    if (!user.active) { setError("Your account has been deactivated. Contact admin."); setLoading(false); return; }
    if (MOCK_PASSWORDS[email] !== password) { setError("Incorrect password."); setLoading(false); return; }
    onLogin(user);
    setLoading(false);
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    await new Promise(r => setTimeout(r, 900));
    // In production: supabase.auth.signInWithOAuth({ provider: 'google' })
    onLogin(MOCK_USERS[1]); // Demo: logs in as Jason
    setGoogleLoading(false);
  };

  return (
    <div style={{ minHeight:"100vh", background:C.bg, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'DM Mono','Courier New',monospace", padding:20 }}>
      <div style={{ width:"100%", maxWidth:400 }}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:40 }}>
          <div style={{ fontSize:28, fontWeight:700, letterSpacing:3, color:C.text, fontFamily:"Georgia,serif" }}>
            FREIGHT<span style={{ color:C.accent }}>FLOW</span>
          </div>
          <div style={{ fontSize:11, color:C.sub, letterSpacing:2, marginTop:6 }}>BROKERAGE SUITE</div>
        </div>

        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:10, padding:32 }}>
          <div style={{ fontSize:13, color:C.text, fontWeight:700, marginBottom:4 }}>Sign in to your account</div>
          <div style={{ fontSize:11, color:C.sub, marginBottom:24 }}>Access your brokerage dashboard</div>

          {/* Google SSO */}
          <button onClick={handleGoogle} disabled={googleLoading}
            style={{ width:"100%", background:C.surf, border:`1px solid ${C.border}`, borderRadius:6, padding:"11px 16px", color:C.text, fontSize:13, cursor:"pointer", fontFamily:"inherit", display:"flex", alignItems:"center", justifyContent:"center", gap:10, marginBottom:20, opacity:googleLoading?0.6:1 }}>
            <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            {googleLoading ? "Signing in..." : "Continue with Google"}
          </button>

          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:20 }}>
            <div style={{ flex:1, height:1, background:C.border }} />
            <span style={{ fontSize:10, color:C.sub, letterSpacing:1 }}>OR</span>
            <div style={{ flex:1, height:1, background:C.border }} />
          </div>

          <Input label="Email Address" type="email" value={email} onChange={setEmail} placeholder="you@company.com" />
          <Input label="Password" type="password" value={password} onChange={setPassword} placeholder="••••••••" />

          {error && <div style={{ background:"#450a0a", border:"1px solid #7f1d1d", borderRadius:5, padding:"8px 12px", fontSize:12, color:C.red, marginBottom:14 }}>{error}</div>}

          <button onClick={handleLogin} disabled={loading || !email || !password}
            style={{ width:"100%", background:C.accent, color:"#000", border:"none", borderRadius:6, padding:12, fontWeight:700, fontSize:13, cursor:loading||!email||!password?"default":"pointer", fontFamily:"inherit", letterSpacing:1, opacity:loading||!email||!password?0.5:1 }}>
            {loading ? "SIGNING IN..." : "SIGN IN →"}
          </button>

          <div style={{ marginTop:16, padding:"10px 12px", background:C.surf, borderRadius:5, border:`1px solid ${C.border}` }}>
            <div style={{ fontSize:10, color:C.sub, letterSpacing:1, marginBottom:6 }}>DEMO ACCOUNTS</div>
            {MOCK_USERS.map(u => (
              <div key={u.id} style={{ fontSize:11, color:C.sub, marginBottom:3, display:"flex", gap:8 }}>
                <span style={{ color: u.role==="admin" ? C.accent : C.blue }}>{u.role === "admin" ? "👑" : "🔹"}</span>
                <span style={{ color:C.text }}>{u.email}</span>
                <span style={{ color:C.sub }}>/ broker123</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Admin Panel ──────────────────────────────────────────────────────────────
function AdminPanel({ users, setUsers, loads, currentUser, onLogout }) {
  const [tab, setTab] = useState("brokers");
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteName, setInviteName] = useState("");
  const [inviteCompany, setInviteCompany] = useState("");
  const [notif, setNotif] = useState(null);
  const [viewingBroker, setViewingBroker] = useState(null);

  const toast = (msg, type="success") => { setNotif({msg,type}); setTimeout(()=>setNotif(null),3500); };

  const totalRevenue = Object.values(loads).flat().reduce((s,l)=>s+l.shipperRate,0);
  const totalMargin = Object.values(loads).flat().reduce((s,l)=>s+(l.shipperRate-l.carrierRate),0);
  const totalLoads = Object.values(loads).flat().length;
  const brokerCount = users.filter(u=>u.role==="broker"&&u.active).length;

  const toggleActive = (id) => {
    setUsers(u => u.map(x => x.id===id ? {...x,active:!x.active} : x));
    toast("Broker status updated.");
  };

  const handleInvite = () => {
    if (!inviteEmail||!inviteName) return;
    const newUser = { id:`u${Date.now()}`, email:inviteEmail, name:inviteName, role:"broker", company:inviteCompany, avatar:inviteName.split(" ").map(n=>n[0]).join("").slice(0,2).toUpperCase(), active:true, joined:new Date().toISOString().split("T")[0] };
    setUsers(u=>[...u,newUser]);
    setInviteEmail(""); setInviteName(""); setInviteCompany("");
    toast(`✓ ${inviteName} added as a broker.`);
  };

  const brokerLoads = (uid) => loads[uid] || [];
  const brokerRevenue = (uid) => brokerLoads(uid).reduce((s,l)=>s+l.shipperRate,0);
  const brokerMargin = (uid) => brokerLoads(uid).reduce((s,l)=>s+(l.shipperRate-l.carrierRate),0);

  const S = {
    container: { minHeight:"100vh", background:C.bg, fontFamily:"'DM Mono','Courier New',monospace" },
    hdr: { borderBottom:`1px solid ${C.border}`, padding:"0 28px", display:"flex", alignItems:"center", justifyContent:"space-between", height:56, background:"#070709" },
    logo: { fontSize:16, fontWeight:700, letterSpacing:2, color:C.text, fontFamily:"Georgia,serif" },
    body: { padding:"24px 28px", maxWidth:1100, margin:"0 auto" },
    tabs: { display:"flex", gap:4, marginBottom:24 },
    tab: (a) => ({ background:a?C.accent:"transparent", color:a?"#000":C.sub, border:"none", padding:"6px 16px", borderRadius:4, cursor:"pointer", fontSize:11, letterSpacing:1, fontFamily:"inherit", fontWeight:a?700:400 }),
    g4: { display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:24 },
    card: { background:C.card, border:`1px solid ${C.border}`, borderRadius:8, padding:"18px 20px" },
    lbl: { fontSize:10, color:C.sub, letterSpacing:2, textTransform:"uppercase", marginBottom:6 },
    val: { fontSize:22, fontWeight:700, color:C.text, fontFamily:"Georgia,serif" },
    sub2: { fontSize:11, color:C.sub, marginTop:3 },
    tbl: { width:"100%", borderCollapse:"collapse" },
    th: { textAlign:"left", fontSize:9, letterSpacing:2, color:"#333", padding:"7px 12px", borderBottom:`1px solid ${C.border}`, textTransform:"uppercase" },
    td: { padding:"11px 12px", borderBottom:`1px solid #0d0f17`, fontSize:12, verticalAlign:"middle" },
    avatar: (active) => ({ width:34, height:34, borderRadius:"50%", background:active?"#1a2a4a":"#1a1d28", border:`2px solid ${active?C.blue:C.muted}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:active?C.blue:C.sub }),
    notif: (t) => ({ position:"fixed", bottom:20, right:20, background:t==="success"?"#052e16":"#450a0a", border:`1px solid ${t==="success"?"#16a34a":"#dc2626"}`, color:t==="success"?C.green:C.red, borderRadius:6, padding:"11px 18px", fontSize:12, zIndex:200 }),
  };

  return (
    <div style={S.container}>
      <div style={S.hdr}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <span style={S.logo}>FREIGHT<span style={{color:C.accent}}>FLOW</span></span>
          <span style={{ fontSize:10, background:"#2a0f00", color:C.accent, border:`1px solid #7c3a10`, borderRadius:3, padding:"2px 8px", letterSpacing:1 }}>👑 ADMIN</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:14 }}>
          <span style={{ fontSize:12, color:C.sub }}>{currentUser.email}</span>
          <button onClick={onLogout} style={{ background:"transparent", border:`1px solid ${C.muted}`, color:C.sub, borderRadius:4, padding:"5px 12px", fontSize:11, cursor:"pointer", fontFamily:"inherit" }}>Sign Out</button>
        </div>
      </div>

      <div style={S.body}>
        {/* Stats */}
        <div style={S.g4}>
          <div style={S.card}><div style={S.lbl}>Active Brokers</div><div style={S.val}>{brokerCount}</div><div style={S.sub2}>{users.filter(u=>u.role==="broker").length} total accounts</div></div>
          <div style={S.card}><div style={S.lbl}>Platform Revenue</div><div style={S.val}>${totalRevenue.toLocaleString()}</div><div style={S.sub2}>{totalLoads} loads</div></div>
          <div style={{...S.card, background:"#180d05", borderColor:"#6b2d0a"}}><div style={S.lbl}>Total Margin</div><div style={{...S.val,color:C.accent}}>${totalMargin.toLocaleString()}</div><div style={S.sub2}>Across all brokers</div></div>
          <div style={S.card}><div style={S.lbl}>Overdue Invoices</div><div style={{...S.val,color:C.red}}>{Object.values(loads).flat().filter(l=>l.invoiceStatus==="overdue").length}</div><div style={S.sub2}>Need attention</div></div>
        </div>

        {/* Tabs */}
        <div style={S.tabs}>
          {[["brokers","Brokers"],["invite","+ Invite Broker"],["activity","All Activity"]].map(([t,l])=>(
            <button key={t} style={S.tab(tab===t)} onClick={()=>setTab(t)}>{l}</button>
          ))}
        </div>

        {/* Brokers List */}
        {tab==="brokers" && (
          <div style={S.card}>
            <table style={S.tbl}>
              <thead><tr>{["Broker","Company","Loads","Revenue","Margin","Status","Actions"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>
                {users.filter(u=>u.role==="broker").map(u=>(
                  <tr key={u.id}>
                    <td style={S.td}>
                      <div style={{display:"flex",alignItems:"center",gap:10}}>
                        <div style={S.avatar(u.active)}>{u.avatar}</div>
                        <div>
                          <div style={{color:C.text,fontWeight:600}}>{u.name}</div>
                          <div style={{fontSize:11,color:C.sub}}>{u.email}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{...S.td,color:C.sub}}>{u.company}</td>
                    <td style={S.td}>{brokerLoads(u.id).length}</td>
                    <td style={S.td}>${brokerRevenue(u.id).toLocaleString()}</td>
                    <td style={{...S.td,color:C.green,fontWeight:600}}>+${brokerMargin(u.id).toLocaleString()}</td>
                    <td style={S.td}><span style={{fontSize:10,fontWeight:700,color:u.active?C.green:C.red}}>● {u.active?"ACTIVE":"INACTIVE"}</span></td>
                    <td style={S.td}>
                      <button style={{background:"transparent",color:C.blue,border:`1px solid ${C.muted}`,borderRadius:4,padding:"3px 10px",fontSize:10,cursor:"pointer",fontFamily:"inherit",marginRight:6}} onClick={()=>setViewingBroker(u)}>View</button>
                      <button style={{background:"transparent",color:u.active?C.red:C.green,border:`1px solid ${C.muted}`,borderRadius:4,padding:"3px 10px",fontSize:10,cursor:"pointer",fontFamily:"inherit"}} onClick={()=>toggleActive(u.id)}>{u.active?"Deactivate":"Activate"}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Invite */}
        {tab==="invite" && (
          <div style={{...S.card,maxWidth:500}}>
            <div style={{fontSize:13,color:C.text,fontWeight:700,marginBottom:4}}>Add a New Broker</div>
            <div style={{fontSize:11,color:C.sub,marginBottom:20}}>They'll receive login credentials and access their own isolated dashboard.</div>
            <Input label="Full Name" value={inviteName} onChange={setInviteName} placeholder="Jane Smith" />
            <Input label="Email Address" type="email" value={inviteEmail} onChange={setInviteEmail} placeholder="jane@company.com" />
            <Input label="Company Name" value={inviteCompany} onChange={setInviteCompany} placeholder="Smith Freight LLC" />
            <button onClick={handleInvite} disabled={!inviteEmail||!inviteName}
              style={{background:C.accent,color:"#000",border:"none",borderRadius:6,padding:"10px 24px",fontWeight:700,fontSize:13,cursor:!inviteEmail||!inviteName?"default":"pointer",fontFamily:"inherit",letterSpacing:1,opacity:!inviteEmail||!inviteName?0.4:1}}>
              ADD BROKER →
            </button>
          </div>
        )}

        {/* All Activity */}
        {tab==="activity" && (
          <div style={S.card}>
            <table style={S.tbl}>
              <thead><tr>{["Load ID","Broker","Shipper","Route","Rate","Margin","Invoice"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>
                {users.filter(u=>u.role==="broker").flatMap(u =>
                  brokerLoads(u.id).map(l => (
                    <tr key={l.id}>
                      <td style={{...S.td,color:C.accent,fontWeight:600}}>{l.id}</td>
                      <td style={S.td}>
                        <div style={{display:"flex",alignItems:"center",gap:8}}>
                          <div style={{...S.avatar(u.active),width:22,height:22,fontSize:9}}>{u.avatar}</div>
                          <span style={{color:C.text}}>{u.name}</span>
                        </div>
                      </td>
                      <td style={S.td}>{l.shipper}</td>
                      <td style={{...S.td,color:C.sub,fontSize:11}}>{l.origin} → {l.destination}</td>
                      <td style={S.td}>${l.shipperRate.toLocaleString()}</td>
                      <td style={{...S.td,color:C.green,fontWeight:600}}>+${(l.shipperRate-l.carrierRate).toLocaleString()}</td>
                      <td style={S.td}><Badge label={l.invoiceStatus} colors={invColors[l.invoiceStatus]||invColors.pending}/></td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Broker Detail Drawer */}
      {viewingBroker && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",zIndex:100,display:"flex",alignItems:"flex-end",justifyContent:"flex-end"}} onClick={()=>setViewingBroker(null)}>
          <div style={{background:C.card,border:`1px solid ${C.border}`,width:420,height:"100vh",padding:24,overflowY:"auto"}} onClick={e=>e.stopPropagation()}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
              <div style={{...S.avatar(viewingBroker.active),width:46,height:46,fontSize:15}}>{viewingBroker.avatar}</div>
              <button onClick={()=>setViewingBroker(null)} style={{background:"transparent",border:`1px solid ${C.muted}`,color:C.sub,borderRadius:4,padding:"4px 10px",cursor:"pointer",fontFamily:"inherit",fontSize:12}}>✕ Close</button>
            </div>
            <div style={{fontSize:17,color:C.text,fontWeight:700,marginBottom:2}}>{viewingBroker.name}</div>
            <div style={{fontSize:12,color:C.sub,marginBottom:4}}>{viewingBroker.email}</div>
            <div style={{fontSize:12,color:C.sub,marginBottom:16}}>{viewingBroker.company}</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:20}}>
              {[["Loads",brokerLoads(viewingBroker.id).length],["Revenue",`$${brokerRevenue(viewingBroker.id).toLocaleString()}`],["Margin",`+$${brokerMargin(viewingBroker.id).toLocaleString()}`],["Joined",viewingBroker.joined]].map(([k,v])=>(
                <div key={k} style={{background:C.bg,borderRadius:6,padding:"10px 12px",border:`1px solid ${C.border}`}}>
                  <div style={{fontSize:9,color:C.sub,letterSpacing:1,textTransform:"uppercase",marginBottom:4}}>{k}</div>
                  <div style={{fontSize:14,color:k==="Margin"?C.green:C.text,fontWeight:700}}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{fontSize:10,color:C.sub,letterSpacing:2,textTransform:"uppercase",marginBottom:10}}>Recent Loads</div>
            {brokerLoads(viewingBroker.id).map(l=>(
              <div key={l.id} style={{background:C.bg,border:`1px solid ${C.border}`,borderRadius:6,padding:"10px 12px",marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{color:C.accent,fontWeight:600,fontSize:12}}>{l.id}</span>
                  <Badge label={l.invoiceStatus} colors={invColors[l.invoiceStatus]||invColors.pending}/>
                </div>
                <div style={{fontSize:12,color:C.text}}>{l.shipper}</div>
                <div style={{fontSize:11,color:C.sub}}>{l.origin} → {l.destination}</div>
                <div style={{fontSize:12,color:C.green,fontWeight:600,marginTop:4}}>+${(l.shipperRate-l.carrierRate).toLocaleString()} margin</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {notif && <div style={S.notif(notif.type)}>{notif.msg}</div>}
    </div>
  );
}

// ─── Broker Dashboard ─────────────────────────────────────────────────────────
function BrokerDashboard({ user, userLoads, onLogout }) {
  const [tab, setTab] = useState("dashboard");
  const revenue = userLoads.reduce((s,l)=>s+l.shipperRate,0);
  const margin = userLoads.reduce((s,l)=>s+(l.shipperRate-l.carrierRate),0);
  const overdue = userLoads.filter(l=>l.invoiceStatus==="overdue").reduce((s,l)=>s+l.shipperRate,0);

  const S = {
    container: { minHeight:"100vh", background:C.bg, fontFamily:"'DM Mono','Courier New',monospace" },
    hdr: { borderBottom:`1px solid ${C.border}`, padding:"0 28px", display:"flex", alignItems:"center", justifyContent:"space-between", height:56, background:"#070709" },
    body: { padding:"24px 28px", maxWidth:1000, margin:"0 auto" },
    g3: { display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14, marginBottom:24 },
    card: { background:C.card, border:`1px solid ${C.border}`, borderRadius:8, padding:"18px 20px" },
    tabs: { display:"flex", gap:4, marginBottom:24 },
    tab: (a) => ({ background:a?C.accent:"transparent", color:a?"#000":C.sub, border:"none", padding:"6px 16px", borderRadius:4, cursor:"pointer", fontSize:11, letterSpacing:1, fontFamily:"inherit", fontWeight:a?700:400 }),
    tbl: { width:"100%", borderCollapse:"collapse" },
    th: { textAlign:"left", fontSize:9, letterSpacing:2, color:"#333", padding:"7px 12px", borderBottom:`1px solid ${C.border}`, textTransform:"uppercase" },
    td: { padding:"11px 12px", borderBottom:`1px solid #0d0f17`, fontSize:12 },
  };

  return (
    <div style={S.container}>
      <div style={S.hdr}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:16, fontWeight:700, letterSpacing:2, color:C.text, fontFamily:"Georgia,serif" }}>FREIGHT<span style={{color:C.accent}}>FLOW</span></span>
          <span style={{ fontSize:11, color:C.sub }}>/ {user.company}</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:14 }}>
          <div style={{ width:30, height:30, borderRadius:"50%", background:"#1a2a4a", border:`2px solid ${C.blue}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:C.blue }}>{user.avatar}</div>
          <span style={{ fontSize:12, color:C.sub }}>{user.name}</span>
          <button onClick={onLogout} style={{ background:"transparent", border:`1px solid ${C.muted}`, color:C.sub, borderRadius:4, padding:"5px 12px", fontSize:11, cursor:"pointer", fontFamily:"inherit" }}>Sign Out</button>
        </div>
      </div>

      <div style={S.body}>
        <div style={S.g3}>
          <div style={S.card}><div style={{fontSize:10,color:C.sub,letterSpacing:2,textTransform:"uppercase",marginBottom:6}}>My Revenue</div><div style={{fontSize:22,fontWeight:700,color:C.text,fontFamily:"Georgia,serif"}}>${revenue.toLocaleString()}</div><div style={{fontSize:11,color:C.sub,marginTop:3}}>{userLoads.length} loads</div></div>
          <div style={{...S.card,background:"#180d05",borderColor:"#6b2d0a"}}><div style={{fontSize:10,color:C.sub,letterSpacing:2,textTransform:"uppercase",marginBottom:6}}>My Margin</div><div style={{fontSize:22,fontWeight:700,color:C.accent,fontFamily:"Georgia,serif"}}>${margin.toLocaleString()}</div><div style={{fontSize:11,color:C.sub,marginTop:3}}>{revenue>0?((margin/revenue)*100).toFixed(1):0}% avg</div></div>
          <div style={S.card}><div style={{fontSize:10,color:C.sub,letterSpacing:2,textTransform:"uppercase",marginBottom:6}}>Overdue</div><div style={{fontSize:22,fontWeight:700,color:overdue>0?C.red:C.text,fontFamily:"Georgia,serif"}}>${overdue.toLocaleString()}</div><div style={{fontSize:11,color:C.sub,marginTop:3}}>{userLoads.filter(l=>l.invoiceStatus==="overdue").length} invoices</div></div>
        </div>

        <div style={S.tabs}>
          {[["dashboard","My Loads"],["invoices","Invoices"],["payments","Payments"]].map(([t,l])=>(
            <button key={t} style={S.tab(tab===t)} onClick={()=>setTab(t)}>{l}</button>
          ))}
        </div>

        <div style={S.card}>
          <table style={S.tbl}>
            <thead>
              <tr>
                {tab==="dashboard" && ["Load","Shipper","Route","Rate","Carrier Pay","Margin","Status"].map(h=><th key={h} style={S.th}>{h}</th>)}
                {tab==="invoices" && ["Invoice","Shipper","Amount","Date","Status"].map(h=><th key={h} style={S.th}>{h}</th>)}
                {tab==="payments" && ["Load","Carrier Pay","Gross","Margin","Status"].map(h=><th key={h} style={S.th}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {userLoads.map(l=>(
                <tr key={l.id}>
                  {tab==="dashboard" && (<>
                    <td style={{...S.td,color:C.accent,fontWeight:600}}>{l.id}</td>
                    <td style={S.td}>{l.shipper}</td>
                    <td style={{...S.td,color:C.sub,fontSize:11}}>{l.origin} → {l.destination}</td>
                    <td style={S.td}>${l.shipperRate.toLocaleString()}</td>
                    <td style={S.td}>${l.carrierRate.toLocaleString()}</td>
                    <td style={{...S.td,color:C.green,fontWeight:600}}>+${(l.shipperRate-l.carrierRate).toLocaleString()}</td>
                    <td style={S.td}><Badge label={l.invoiceStatus} colors={invColors[l.invoiceStatus]||invColors.pending}/></td>
                  </>)}
                  {tab==="invoices" && (<>
                    <td style={{...S.td,color:C.accent}}>INV-{l.id}</td>
                    <td style={S.td}>{l.shipper}</td>
                    <td style={{...S.td,fontWeight:600}}>${l.shipperRate.toLocaleString()}</td>
                    <td style={{...S.td,color:C.sub}}>{l.date}</td>
                    <td style={S.td}><Badge label={l.invoiceStatus} colors={invColors[l.invoiceStatus]||invColors.pending}/></td>
                  </>)}
                  {tab==="payments" && (<>
                    <td style={{...S.td,color:C.accent,fontWeight:600}}>{l.id}</td>
                    <td style={{...S.td,color:C.green,fontWeight:700}}>${l.carrierRate.toLocaleString()}</td>
                    <td style={S.td}>${l.shipperRate.toLocaleString()}</td>
                    <td style={{...S.td,color:C.accent}}>−${(l.shipperRate-l.carrierRate).toLocaleString()}</td>
                    <td style={S.td}><Badge label={l.invoiceStatus} colors={invColors[l.invoiceStatus]||invColors.pending}/></td>
                  </>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── App Root ─────────────────────────────────────────────────────────────────
export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState(MOCK_USERS);
  const [loads] = useState(MOCK_LOADS);

  if (!currentUser) return <LoginScreen onLogin={setCurrentUser} />;

  if (currentUser.role === "admin") return (
    <AdminPanel users={users} setUsers={setUsers} loads={loads} currentUser={currentUser} onLogout={() => setCurrentUser(null)} />
  );

  return (
    <BrokerDashboard user={currentUser} userLoads={loads[currentUser.id] || []} onLogout={() => setCurrentUser(null)} />
  );
}
