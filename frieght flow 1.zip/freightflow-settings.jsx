import { useState } from "react";

// ─── Plan Config ──────────────────────────────────────────────────────────────
const PLANS = {
  starter: {
    name: "Starter", price: 49, priceAnnual: 470, seats: 1,
    color: "#60a5fa", badge: null,
    features: ["1 user — solo broker","Unlimited loads","Gmail inbox watcher","Invoice & payment automation","Email support"],
  },
  growth: {
    name: "Growth", price: 99, priceAnnual: 950, seats: 4,
    color: "#f97316", badge: "MOST POPULAR",
    features: ["1 admin + 3 workers","Everything in Starter","Team load visibility","QuickBooks sync","Priority email support"],
  },
  pro: {
    name: "Pro", price: 199, priceAnnual: 1900, seats: Infinity,
    color: "#a78bfa", badge: "BEST VALUE",
    features: ["1 admin + unlimited workers","Everything in Growth","White-label branding","API access","Dedicated support"],
  },
};

// ─── Mock current user/company ────────────────────────────────────────────────
const MOCK_COMPANY = {
  id: "c1", name: "Midwest Brokers LLC", plan: "growth",
  subStatus: "active", subPeriodEnd: "2024-07-15",
  seatsUsed: 2, stripeCustomerId: "cus_mock123",
};
const MOCK_USER = { id: "u1", name: "Jason Cole", email: "jason@midwestbrokers.com", role: "admin", avatar: "JC" };
const MOCK_TEAM = [
  { id: "m1", email: "jason@midwestbrokers.com", name: "Jason Cole", role: "admin", status: "active", avatar: "JC" },
  { id: "m2", email: "sara@midwestbrokers.com", name: "Sara Kim", role: "worker", status: "active", avatar: "SK" },
  { id: "m3", email: "pending@midwestbrokers.com", name: null, role: "worker", status: "pending", avatar: "?" },
];

// ─── Colors ───────────────────────────────────────────────────────────────────
const C = {
  bg:"#09090f", surf:"#0f1018", card:"#13151f", border:"#1c1f2e",
  text:"#e2e2e2", sub:"#4a4d5e", muted:"#2a2d3e",
  accent:"#f97316", green:"#4ade80", blue:"#60a5fa", red:"#f87171", purple:"#a78bfa",
};

// ─── Small Components ─────────────────────────────────────────────────────────
const Input = ({ label, type="text", value, onChange, placeholder, disabled }) => (
  <div style={{ marginBottom:16 }}>
    <label style={{ display:"block", fontSize:10, color:C.sub, letterSpacing:2, textTransform:"uppercase", marginBottom:6 }}>{label}</label>
    <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} disabled={disabled}
      style={{ width:"100%", background:disabled?"#0a0b10":C.surf, border:`1px solid ${C.border}`, borderRadius:6, padding:"10px 14px", color:disabled?C.sub:C.text, fontSize:13, fontFamily:"inherit", boxSizing:"border-box", opacity:disabled?0.6:1 }} />
  </div>
);

const SectionCard = ({ title, sub, children }) => (
  <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:8, padding:"22px 24px", marginBottom:16 }}>
    {title && <div style={{ fontSize:14, color:C.text, fontWeight:700, marginBottom:sub?4:16 }}>{title}</div>}
    {sub && <div style={{ fontSize:11, color:C.sub, marginBottom:16 }}>{sub}</div>}
    {children}
  </div>
);

const Btn = ({ label, onClick, variant="primary", disabled, full }) => {
  const v = {
    primary:  { bg:C.accent,   color:"#000",   border:"none" },
    secondary:{ bg:"transparent", color:C.sub, border:`1px solid ${C.muted}` },
    danger:   { bg:"#450a0a",  color:C.red,    border:"1px solid #7f1d1d" },
    success:  { bg:"#052e16",  color:C.green,  border:"1px solid #166534" },
    purple:   { bg:"#1a0a3a",  color:C.purple, border:"1px solid #5b21b6" },
  }[variant];
  return (
    <button onClick={onClick} disabled={disabled}
      style={{ ...v, borderRadius:6, padding:"9px 20px", fontWeight:700, fontSize:12, cursor:disabled?"default":"pointer", fontFamily:"inherit", letterSpacing:1, opacity:disabled?0.5:1, width:full?"100%":"auto" }}>
      {label}
    </button>
  );
};

const Notif = ({ msg, type }) => (
  <div style={{ position:"fixed", bottom:20, right:20, background:type==="error"?"#450a0a":"#052e16", border:`1px solid ${type==="error"?"#dc2626":"#16a34a"}`, color:type==="error"?C.red:C.green, borderRadius:6, padding:"11px 18px", fontSize:12, zIndex:200, maxWidth:380 }}>
    {msg}
  </div>
);

// ─── Pricing Page ─────────────────────────────────────────────────────────────
function PricingPage({ currentPlan, onSubscribe }) {
  const [billing, setBilling] = useState("monthly");

  return (
    <div>
      <div style={{ textAlign:"center", marginBottom:32 }}>
        <div style={{ fontSize:11, color:C.sub, letterSpacing:3, textTransform:"uppercase", marginBottom:8 }}>Subscription</div>
        <div style={{ fontSize:24, color:C.text, fontWeight:700, fontFamily:"Georgia,serif", marginBottom:12 }}>
          Choose your plan
        </div>
        <div style={{ fontSize:13, color:C.sub, marginBottom:24 }}>
          Keep billing automatically until you cancel. No contracts, no surprises.
        </div>

        {/* Billing toggle */}
        <div style={{ display:"inline-flex", background:C.surf, border:`1px solid ${C.border}`, borderRadius:6, padding:3, gap:3 }}>
          {["monthly","annual"].map(b => (
            <button key={b} onClick={()=>setBilling(b)}
              style={{ background:billing===b?C.accent:"transparent", color:billing===b?"#000":C.sub, border:"none", borderRadius:4, padding:"6px 18px", fontSize:11, cursor:"pointer", fontFamily:"inherit", fontWeight:billing===b?700:400, letterSpacing:1 }}>
              {b === "annual" ? "ANNUAL — SAVE 20%" : "MONTHLY"}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, maxWidth:900, margin:"0 auto" }}>
        {Object.entries(PLANS).map(([key, plan]) => {
          const isCurrent = currentPlan === key;
          const price = billing === "annual" ? Math.round(plan.priceAnnual / 12) : plan.price;
          const totalAnnual = plan.priceAnnual;

          return (
            <div key={key} style={{
              background: isCurrent ? "#13151f" : C.card,
              border: `2px solid ${isCurrent ? plan.color : C.border}`,
              borderRadius: 10, padding: 24, position: "relative",
              boxShadow: isCurrent ? `0 0 24px ${plan.color}22` : "none",
            }}>
              {plan.badge && (
                <div style={{ position:"absolute", top:-11, left:"50%", transform:"translateX(-50%)", background:plan.color, color:"#000", fontSize:9, fontWeight:700, letterSpacing:2, padding:"3px 12px", borderRadius:20 }}>
                  {plan.badge}
                </div>
              )}
              {isCurrent && (
                <div style={{ position:"absolute", top:12, right:12, background:"#052e16", color:C.green, fontSize:9, fontWeight:700, letterSpacing:1, padding:"2px 8px", borderRadius:3 }}>
                  CURRENT
                </div>
              )}

              <div style={{ fontSize:11, color:plan.color, letterSpacing:2, textTransform:"uppercase", marginBottom:8 }}>{plan.name}</div>
              <div style={{ fontSize:36, fontWeight:700, color:C.text, fontFamily:"Georgia,serif" }}>
                ${price}<span style={{ fontSize:14, color:C.sub, fontWeight:400 }}>/mo</span>
              </div>
              {billing === "annual" && (
                <div style={{ fontSize:11, color:C.sub, marginBottom:8 }}>${totalAnnual}/yr billed annually</div>
              )}
              <div style={{ fontSize:11, color:C.sub, marginBottom:20 }}>
                {plan.seats === Infinity ? "Unlimited workers" : plan.seats === 1 ? "Solo broker" : `Up to ${plan.seats} users`}
              </div>

              <div style={{ marginBottom:24 }}>
                {plan.features.map((f, i) => (
                  <div key={i} style={{ display:"flex", gap:8, alignItems:"flex-start", marginBottom:8 }}>
                    <span style={{ color:plan.color, fontSize:12, marginTop:1 }}>✓</span>
                    <span style={{ fontSize:12, color:C.sub }}>{f}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => !isCurrent && onSubscribe(key, billing)}
                disabled={isCurrent}
                style={{
                  width:"100%", background:isCurrent?"transparent":plan.color,
                  color:isCurrent?C.sub:"#000",
                  border:`1px solid ${isCurrent?C.muted:plan.color}`,
                  borderRadius:6, padding:"10px 0", fontWeight:700, fontSize:12,
                  cursor:isCurrent?"default":"pointer", fontFamily:"inherit", letterSpacing:1,
                  opacity:isCurrent?0.5:1,
                }}>
                {isCurrent ? "Current Plan" : `Subscribe — $${price}/mo`}
              </button>
            </div>
          );
        })}
      </div>

      <div style={{ textAlign:"center", marginTop:24, fontSize:11, color:C.sub }}>
        💳 Powered by Stripe · Cancel anytime · No contracts
      </div>
    </div>
  );
}

// ─── Account Settings ─────────────────────────────────────────────────────────
function AccountSettings({ user, company, onSave }) {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [companyName, setCompanyName] = useState(company.name);
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [pwError, setPwError] = useState("");
  const [notif, setNotif] = useState(null);

  const toast = (msg, type="success") => { setNotif({msg,type}); setTimeout(()=>setNotif(null),3000); };

  const saveProfile = () => {
    // supabase.from("profiles").update({ name, company: companyName }).eq("id", user.id)
    toast("Profile updated successfully.");
    onSave({ name, companyName });
  };

  const savePassword = () => {
    setPwError("");
    if (newPw.length < 8) { setPwError("Password must be at least 8 characters."); return; }
    if (newPw !== confirmPw) { setPwError("Passwords don't match."); return; }
    // supabase.auth.updateUser({ password: newPw })
    toast("Password updated.");
    setCurrentPw(""); setNewPw(""); setConfirmPw("");
  };

  const sendResetEmail = () => {
    // supabase.auth.resetPasswordForEmail(user.email)
    toast(`Password reset email sent to ${user.email}`);
  };

  return (
    <div style={{ maxWidth:560 }}>
      <SectionCard title="Profile" sub="Update your name and company details">
        <Input label="Full Name" value={name} onChange={setName} />
        <Input label="Company Name" value={companyName} onChange={setCompanyName} />
        <Input label="Email Address" type="email" value={email} onChange={setEmail} />
        <Btn label="Save Profile" onClick={saveProfile} />
      </SectionCard>

      <SectionCard title="Change Password" sub="Must be at least 8 characters">
        <Input label="Current Password" type="password" value={currentPw} onChange={setCurrentPw} placeholder="••••••••" />
        <Input label="New Password" type="password" value={newPw} onChange={setNewPw} placeholder="••••••••" />
        <Input label="Confirm New Password" type="password" value={confirmPw} onChange={setConfirmPw} placeholder="••••••••" />
        {pwError && <div style={{ color:C.red, fontSize:12, marginBottom:12 }}>{pwError}</div>}
        <div style={{ display:"flex", gap:10 }}>
          <Btn label="Update Password" onClick={savePassword} disabled={!currentPw||!newPw||!confirmPw} />
          <Btn label="Email Reset Link" onClick={sendResetEmail} variant="secondary" />
        </div>
      </SectionCard>

      <SectionCard title="Danger Zone">
        <div style={{ fontSize:12, color:C.sub, marginBottom:12 }}>
          Deleting your account is permanent and cannot be undone. All your data will be removed.
        </div>
        <Btn label="Delete My Account" variant="danger" onClick={() => alert("In production: confirm then delete via Supabase admin.")} />
      </SectionCard>

      {notif && <Notif {...notif} />}
    </div>
  );
}

// ─── Team Management ──────────────────────────────────────────────────────────
function TeamManagement({ company, team, setTeam, onUpgrade }) {
  const [inviteEmail, setInviteEmail] = useState("");
  const [notif, setNotif] = useState(null);
  const plan = PLANS[company.plan];
  const seatLimit = plan.seats;
  const seatsUsed = team.filter(m => m.status !== "removed").length;
  const canInvite = seatLimit === Infinity || seatsUsed < seatLimit;

  const toast = (msg, type="success") => { setNotif({msg,type}); setTimeout(()=>setNotif(null),3500); };

  const handleInvite = () => {
    if (!inviteEmail) return;
    if (!canInvite) { toast("Seat limit reached. Upgrade your plan to add more workers.", "error"); return; }
    if (team.find(m => m.email === inviteEmail)) { toast("This email is already on your team.", "error"); return; }
    setTeam(t => [...t, { id:`m${Date.now()}`, email:inviteEmail, name:null, role:"worker", status:"pending", avatar:"?" }]);
    toast(`Invite sent to ${inviteEmail}`);
    setInviteEmail("");
  };

  const handleRemove = (id) => {
    setTeam(t => t.map(m => m.id===id ? {...m,status:"removed"} : m));
    toast("Worker removed from team.");
  };

  const activeTeam = team.filter(m => m.status !== "removed");

  return (
    <div style={{ maxWidth:620 }}>
      {/* Seat usage */}
      <SectionCard>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
          <div>
            <div style={{ fontSize:13, color:C.text, fontWeight:700 }}>Team Seats</div>
            <div style={{ fontSize:11, color:C.sub, marginTop:2 }}>
              {plan.name} plan · {seatLimit === Infinity ? "Unlimited seats" : `${seatLimit} seats included`}
            </div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:22, fontWeight:700, color:canInvite?C.green:C.red }}>
              {seatsUsed}{seatLimit !== Infinity && `/${seatLimit}`}
            </div>
            <div style={{ fontSize:10, color:C.sub }}>SEATS USED</div>
          </div>
        </div>

        {/* Seat bar */}
        {seatLimit !== Infinity && (
          <div style={{ height:6, background:C.border, borderRadius:3, overflow:"hidden" }}>
            <div style={{ height:"100%", width:`${Math.min(100,(seatsUsed/seatLimit)*100)}%`, background:canInvite?C.green:C.red, borderRadius:3, transition:"width 0.3s" }} />
          </div>
        )}

        {!canInvite && (
          <div style={{ marginTop:12, padding:"10px 14px", background:"#1a0d05", border:`1px solid #7c3a10`, borderRadius:6, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontSize:12, color:C.accent }}>Seat limit reached — upgrade to add more workers</span>
            <button onClick={onUpgrade} style={{ background:C.accent, color:"#000", border:"none", borderRadius:4, padding:"5px 14px", fontSize:11, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>Upgrade</button>
          </div>
        )}
      </SectionCard>

      {/* Invite */}
      {company.plan !== "starter" && (
        <SectionCard title="Invite a Worker" sub="They'll receive an email with a link to join your team">
          <div style={{ display:"flex", gap:10 }}>
            <input
              type="email" value={inviteEmail} onChange={e=>setInviteEmail(e.target.value)}
              placeholder="worker@company.com"
              style={{ flex:1, background:C.surf, border:`1px solid ${C.border}`, borderRadius:6, padding:"10px 14px", color:C.text, fontSize:13, fontFamily:"inherit" }}
            />
            <button onClick={handleInvite} disabled={!inviteEmail||!canInvite}
              style={{ background:C.accent, color:"#000", border:"none", borderRadius:6, padding:"10px 20px", fontWeight:700, fontSize:12, cursor:"pointer", fontFamily:"inherit", letterSpacing:1, opacity:!inviteEmail||!canInvite?0.4:1 }}>
              INVITE →
            </button>
          </div>
        </SectionCard>
      )}

      {company.plan === "starter" && (
        <SectionCard>
          <div style={{ padding:"16px 0", textAlign:"center" }}>
            <div style={{ fontSize:24, marginBottom:8 }}>👥</div>
            <div style={{ fontSize:13, color:C.text, fontWeight:600, marginBottom:6 }}>Add workers to your team</div>
            <div style={{ fontSize:12, color:C.sub, marginBottom:16 }}>Upgrade to Growth or Pro to invite workers who can see all your loads and help manage billing.</div>
            <button onClick={onUpgrade} style={{ background:C.accent, color:"#000", border:"none", borderRadius:6, padding:"10px 24px", fontWeight:700, fontSize:12, cursor:"pointer", fontFamily:"inherit", letterSpacing:1 }}>
              Upgrade Plan →
            </button>
          </div>
        </SectionCard>
      )}

      {/* Team list */}
      <SectionCard title={`Team Members (${activeTeam.length})`}>
        {activeTeam.map(m => (
          <div key={m.id} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 0", borderBottom:`1px solid ${C.border}` }}>
            <div style={{ display:"flex", alignItems:"center", gap:12 }}>
              <div style={{ width:34, height:34, borderRadius:"50%", background:m.role==="admin"?"#2a0f00":"#0c1a3b", border:`2px solid ${m.role==="admin"?C.accent:C.blue}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:m.role==="admin"?C.accent:C.blue }}>
                {m.avatar}
              </div>
              <div>
                <div style={{ fontSize:13, color:m.status==="pending"?C.sub:C.text, fontWeight:600 }}>
                  {m.name || m.email}
                  {m.status==="pending" && <span style={{ fontSize:10, color:C.yellow, marginLeft:8, background:"#422006", padding:"1px 7px", borderRadius:3 }}>PENDING</span>}
                </div>
                {m.name && <div style={{ fontSize:11, color:C.sub }}>{m.email}</div>}
              </div>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <span style={{ fontSize:10, color:m.role==="admin"?C.accent:C.blue, fontWeight:700, letterSpacing:1 }}>
                {m.role.toUpperCase()}
              </span>
              {m.role !== "admin" && (
                <button onClick={()=>handleRemove(m.id)}
                  style={{ background:"transparent", color:C.red, border:`1px solid #7f1d1d`, borderRadius:4, padding:"3px 10px", fontSize:10, cursor:"pointer", fontFamily:"inherit" }}>
                  Remove
                </button>
              )}
            </div>
          </div>
        ))}
      </SectionCard>

      {notif && <Notif {...notif} />}
    </div>
  );
}

// ─── Billing Settings ─────────────────────────────────────────────────────────
function BillingSettings({ company, onManageBilling, onUpgrade }) {
  const plan = PLANS[company.plan];
  const statusColor = { active:C.green, inactive:C.sub, canceled:C.red, past_due:C.yellow }[company.subStatus] || C.sub;

  return (
    <div style={{ maxWidth:560 }}>
      {/* Current plan */}
      <SectionCard>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20 }}>
          <div>
            <div style={{ fontSize:11, color:plan.color, letterSpacing:2, textTransform:"uppercase", marginBottom:4 }}>{plan.name} Plan</div>
            <div style={{ fontSize:28, fontWeight:700, color:C.text, fontFamily:"Georgia,serif" }}>${plan.price}<span style={{ fontSize:13, color:C.sub, fontWeight:400 }}>/mo</span></div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:11, fontWeight:700, color:statusColor, letterSpacing:1 }}>● {company.subStatus.toUpperCase()}</div>
            {company.subStatus === "active" && (
              <div style={{ fontSize:11, color:C.sub, marginTop:4 }}>Renews {company.subPeriodEnd}</div>
            )}
          </div>
        </div>

        <div style={{ marginBottom:20 }}>
          {plan.features.map((f, i) => (
            <div key={i} style={{ display:"flex", gap:8, marginBottom:6 }}>
              <span style={{ color:plan.color }}>✓</span>
              <span style={{ fontSize:12, color:C.sub }}>{f}</span>
            </div>
          ))}
        </div>

        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onManageBilling}
            style={{ background:C.surf, color:C.text, border:`1px solid ${C.border}`, borderRadius:6, padding:"9px 18px", fontWeight:700, fontSize:12, cursor:"pointer", fontFamily:"inherit", letterSpacing:1 }}>
            💳 Manage Billing
          </button>
          {company.plan !== "pro" && (
            <button onClick={onUpgrade}
              style={{ background:C.accent, color:"#000", border:"none", borderRadius:6, padding:"9px 18px", fontWeight:700, fontSize:12, cursor:"pointer", fontFamily:"inherit", letterSpacing:1 }}>
              ⬆ Upgrade Plan
            </button>
          )}
        </div>
      </SectionCard>

      <SectionCard title="Billing Portal" sub="Powered by Stripe — update payment method, download invoices, cancel subscription">
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {[
            ["💳 Update Credit Card", "Change your payment method"],
            ["📄 Download Invoices", "Access all your billing history"],
            ["⚠️ Cancel Subscription", "Access continues until end of billing period"],
          ].map(([action, desc]) => (
            <div key={action} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 14px", background:C.bg, borderRadius:6, border:`1px solid ${C.border}` }}>
              <div>
                <div style={{ fontSize:12, color:C.text }}>{action}</div>
                <div style={{ fontSize:11, color:C.sub }}>{desc}</div>
              </div>
              <button onClick={onManageBilling}
                style={{ background:"transparent", color:C.blue, border:`1px solid ${C.muted}`, borderRadius:4, padding:"4px 12px", fontSize:11, cursor:"pointer", fontFamily:"inherit" }}>
                Open →
              </button>
            </div>
          ))}
        </div>
        <div style={{ marginTop:12, fontSize:11, color:C.sub }}>
          Billing is handled securely by Stripe. FreightFlow never stores your card details.
        </div>
      </SectionCard>
    </div>
  );
}

// ─── Main Settings App ────────────────────────────────────────────────────────
export default function SettingsApp() {
  const [tab, setTab] = useState("account");
  const [company, setCompany] = useState(MOCK_COMPANY);
  const [user, setUser] = useState(MOCK_USER);
  const [team, setTeam] = useState(MOCK_TEAM);
  const [notif, setNotif] = useState(null);

  const toast = (msg, type="success") => { setNotif({msg,type}); setTimeout(()=>setNotif(null),3500); };

  const handleSubscribe = (planKey, billing) => {
    // In production: startCheckout(planKey, billing, user.id, user.email, company.id)
    setCompany(c => ({...c, plan: planKey, subStatus:"active"}));
    toast(`Subscribed to ${PLANS[planKey].name} plan! (Demo — Stripe not connected)`);
    setTab("billing");
  };

  const handleManageBilling = () => {
    // In production: openBillingPortal(company.stripeCustomerId)
    toast("Opens Stripe Customer Portal in production.");
  };

  const S = {
    app: { minHeight:"100vh", background:C.bg, fontFamily:"'DM Mono','Courier New',monospace" },
    hdr: { borderBottom:`1px solid ${C.border}`, padding:"0 28px", display:"flex", alignItems:"center", justifyContent:"space-between", height:56, background:"#070709" },
    body: { padding:"28px 32px", maxWidth:1100, margin:"0 auto" },
    sidebar: { width:200, flexShrink:0 },
    sideItem: (a) => ({ display:"block", width:"100%", textAlign:"left", background:a?"#1a1d28":"transparent", color:a?C.text:C.sub, border:"none", padding:"9px 14px", borderRadius:5, cursor:"pointer", fontSize:12, fontFamily:"inherit", marginBottom:3, letterSpacing:0.5 }),
    content: { flex:1, minWidth:0 },
    layout: { display:"flex", gap:32 },
  };

  const tabs = [
    ["account", "👤 Account"],
    ["team", "👥 Team"],
    ["billing", "💳 Billing"],
    ["pricing", "📦 Plans"],
  ];

  return (
    <div style={S.app}>
      <div style={S.hdr}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <span style={{ fontSize:16, fontWeight:700, letterSpacing:2, color:C.text, fontFamily:"Georgia,serif" }}>FREIGHT<span style={{color:C.accent}}>FLOW</span></span>
          <span style={{ fontSize:11, color:C.sub }}>/ Settings</span>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ width:30, height:30, borderRadius:"50%", background:"#1a2a4a", border:`2px solid ${C.blue}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, color:C.blue }}>{user.avatar}</div>
          <span style={{ fontSize:12, color:C.sub }}>{user.name}</span>
          <span style={{ fontSize:10, background:"#1a1d28", color:C.sub, borderRadius:3, padding:"2px 8px", letterSpacing:1 }}>{PLANS[company.plan].name.toUpperCase()}</span>
        </div>
      </div>

      <div style={S.body}>
        <div style={{ fontSize:10, color:C.sub, letterSpacing:3, textTransform:"uppercase", marginBottom:20 }}>Account Settings</div>
        <div style={S.layout}>
          {/* Sidebar */}
          <div style={S.sidebar}>
            {tabs.map(([t, l]) => (
              <button key={t} style={S.sideItem(tab===t)} onClick={()=>setTab(t)}>{l}</button>
            ))}
          </div>

          {/* Content */}
          <div style={S.content}>
            {tab==="account" && <AccountSettings user={user} company={company} onSave={({name,companyName})=>{setUser(u=>({...u,name})); setCompany(c=>({...c,name:companyName}));}} />}
            {tab==="team" && <TeamManagement company={company} team={team} setTeam={setTeam} onUpgrade={()=>setTab("pricing")} />}
            {tab==="billing" && <BillingSettings company={company} onManageBilling={handleManageBilling} onUpgrade={()=>setTab("pricing")} />}
            {tab==="pricing" && <PricingPage currentPlan={company.plan} onSubscribe={handleSubscribe} />}
          </div>
        </div>
      </div>

      {notif && <Notif {...notif} />}
    </div>
  );
}
